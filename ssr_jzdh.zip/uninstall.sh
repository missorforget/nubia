#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/ssr_jzdh"

systemctl disable ssr.service >/dev/null 2>&1
systemctl stop ssr.service

rm -rf $wp
rm -f /etc/systemd/system/ssr.service
rm -f /bin/ssr
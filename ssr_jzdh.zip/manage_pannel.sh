#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/ssr_jzdh"

RED="\033[31m"      # Error message
GREEN="\033[32m"    # Success message
YELLOW="\033[33m"   # Warning message
BLUE="\033[36m"     # Info message

add_port() {
    echo
    read -p $'\033[33m请设置端口[默认随机]: \033[0m' Port
    [ -z "$Port" ] && Port=$(($RANDOM+37))
    echo
    read -p $'\033[33m请设置密码[默认随机]: \033[0m' Passport
    [ -z "$Passport" ] && Passport=$(($RANDOM * 1317))
    echo
    read -p $'\033[33m请设置流量[单位G][默认999]: \033[0m' Trafic
    [ -z "$Trafic" ] && Trafic=999
    echo

    cd $wp/shadowsocksr
    python mujson_mgr.py -a -u $Port -p $Port -k $Passport -m chacha20 -O auth_sha1_v4 -o http_simple -t $Trafic >/dev/null 2>&1
    ps -ef | grep "server.py m" | grep -v "grep" >/dev/null 2>&1 && systemctl restart ssr.service
}

del_port() {
    echo
    if (($(cd $wp/shadowsocksr && python mujson_mgr.py -l | wc -l)>1));then
        var=1
        for Echo in $ssr_ports;do
            echo -e " $var. 删除\033[33m$Echo\033[0m端口"
            var=$(($var+1))
        done
        echo
        read -p $'\033[33m请选择: \033[0m' input_choice
        if [ ! -z "$input_choice" ];then
            cd $wp/shadowsocksr && python mujson_mgr.py -d -u $(echo "$ssr_ports" | tr "\n" " " | awk '{print $'$input_choice'}') >/dev/null 2>&1
            ps -ef | grep "server.py m" | grep -v "grep" >/dev/null 2>&1 && systemctl restart ssr.service
        fi
    fi
}

change_passport() {
    echo
    var=1
    for Echo in $ssr_ports;do
        echo -e " $var. 更改\033[33m$Echo\033[0m端口密码"
        var=$(($var+1))
    done
    echo
    read -p $'\033[33m请选择: \033[0m' input_choice
    if [ ! -z "$input_choice" ];then
        echo
        read -p $'\033[33m请设置密码[默认随机]: \033[0m' Passport
        [ -z "$Passport" ] && Passport=$(($RANDOM * 1317))

        cd $wp/shadowsocksr
        python mujson_mgr.py -e -u $(echo "$ssr_ports" | tr "\n" " " | awk '{print $'$input_choice'}') -k $Passport >/dev/null 2>&1
        ps -ef | grep "server.py m" | grep -v "grep" >/dev/null 2>&1 && systemctl restart ssr.service
    fi
}

show_config() {
    echo -e "\033[32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m"
    for K in ${ssr_ports};do
        SSR=$(cd $wp/shadowsocksr && python mujson_mgr.py -l -u $K | sed -n '$p' | sed 's|^[ \t]*||')
        Passport=$(cd $wp/shadowsocksr && python mujson_mgr.py -l -u $K | sed -n "5p" | awk '{print $3}')
        printf "\033[36m%11s \033[33m%-s\033[0m\n" "服务IP:" "$public_ip"
        printf "\033[36m%13s \033[33m%-s\033[0m\n" "服务端口:" "$K"
        printf "\033[36m%11s \033[33m%-s\033[0m\n" "密码:" "$Passport"
        printf "\033[36m%13s \033[33m%-s\033[0m\n" "加密方法:" "chacha20"
        printf "\033[36m%11s \033[33m%-s\033[0m\n" "协议:" "auth_sha1_v4"
        printf "\033[36m%13s \033[33m%-s\033[0m\n" "混淆方式:" "http_simple"
        echo
        printf "\033[36m%9s \033[33m%-s\033[0m\n" "SSR:" "$SSR"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    done
}

pannel(){
    ps -ef | grep "server.py m" | grep -v "grep" >/dev/null 2>&1 && ssr_status="$GREEN" || ssr_status=""
    pgrep koolproxy >/dev/null 2>&1 && koolproxy_status="$GREEN" || koolproxy_status=""
    ssr_ports=$(cd $wp/shadowsocksr && python mujson_mgr.py -l | awk '{print $4}')
    connections=""
    for Port in $ssr_ports;do
        connection=$(echo -e "[\033[33m$Port\033[0m \033[32m$(netstat -anp | grep "^tcp.*ESTABLISHED" | awk '{if($4~/:'$Port'$/)print $5}' | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort -u | wc -l)\033[0m]")
        connections="$connection $connections"
    done
    var=1

    show_config
    echo
    echo -e "[\033[33m端口\033[0m \033[32m连接数\033[0m] $connections"
    echo
    echo -e "  $var. 开/关${ssr_status}ssr\033[0m" && var=$(($var+1))
    echo -e "  $var. 开/关${koolproxy_status}koolproxy\033[0m去广告" && var=$(($var+1))
    echo "  $var. 卸载ssr" && var=$(($var+1))
    echo "  $var. 添加一个端口" && var=$(($var+1))
    echo "  $var. 删除一个端口" && var=$(($var+1))
    echo "  $var. 更改端口密码" && var=$(($var+1))
    echo
    read -p $'\033[33m请选择：\033[0m' pannel_choice

    case $pannel_choice in
        1)
            if [ "$ssr_status" = "$GREEN" ];then
                systemctl stop ssr.service
                systemctl disable ssr.service
            else
                systemctl start ssr.service
                systemctl enable ssr.service
            fi >/dev/null 2>&1
            clear && pannel
            ;;
        2)
            if [ "$koolproxy_status" = "$GREEN" ];then
                iptables -t nat -D OUTPUT -p tcp -m ttl --ttl-eq 160 -j ACCEPT
                iptables -t nat -D OUTPUT -p tcp --dport 80 -j REDIRECT --to 3000
                systemctl stop koolproxy.service
                systemctl disable koolproxy.service
                sed -i 's|koolproxy=.*|koolproxy=off|' $wp/ssr_update.sh
            else
                iptables -t nat -A OUTPUT -p tcp -m ttl --ttl-eq 160 -j ACCEPT
                iptables -t nat -A OUTPUT -p tcp --dport 80 -j REDIRECT --to 3000
                systemctl start koolproxy.service
                systemctl enable koolproxy.service
                sed -i 's|koolproxy=.*|koolproxy=on|' $wp/ssr_update.sh
            fi >/dev/null 2>&1
            clear && pannel
            ;;
        3)
            read
            bash $wp/uninstall.sh
            clear && echo "ssr已卸载！"
            ;;
        4)
            add_port
            clear && pannel
            ;;
        5)
            del_port
            clear && pannel
            ;;
        6)
            change_passport
            clear && pannel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

if grep -q "^##" /bin/ssr;then
    public_ip=$(grep "^##" /bin/ssr | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
else
    public_ip=$(curl -s http://ip-api.com/json | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}')
    sed -i '$a##'$public_ip'' /bin/ssr
fi

clear && pannel

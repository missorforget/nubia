#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/koolproxy"

RED="\033[31m"      # Error message
GREEN="\033[32m"    # Success message
YELLOW="\033[33m"   # Warning message
BLUE="\033[36m"     # Info message

control_koolproxy() {
    pgrep koolproxy >/dev/null 2>&1 && koolproxy_status="$GREEN" || koolproxy_status=""
    if [ "$koolproxy_status" = "$GREEN" ];then
        iptables -t nat -D OUTPUT -p tcp -m ttl --ttl-eq 160 -j ACCEPT
        iptables -t nat -D OUTPUT -p tcp --dport 80 -j REDIRECT --to 3000
        pkill koolproxy
        sed -i 's|koolproxy=.*|koolproxy=off|' $wp/koolproxy_update.sh
    else
        iptables -t nat -A OUTPUT -p tcp -m ttl --ttl-eq 160 -j ACCEPT
        iptables -t nat -A OUTPUT -p tcp --dport 80 -j REDIRECT --to 3000
        nohup $wp/koolproxy --ttl 160 >/dev/null 2>&1 &
        sed -i 's|koolproxy=.*|koolproxy=on|' $wp/koolproxy_update.sh
    fi >/dev/null 2>&1
}

pannel(){
    pgrep koolproxy >/dev/null 2>&1 && koolproxy_status="$GREEN" || koolproxy_status=""
    var=1

    echo
    echo -e "  $var. 开/关${koolproxy_status}koolproxy\033[0m去广告" && var=$(($var+1))
    echo "  $var. 卸载koolproxy" && var=$(($var+1))
    echo
    read -p $'\033[33m请选择：\033[0m' pannel_choice

    case $pannel_choice in
        1)
            control_koolproxy
            clear && pannel
            ;;
        2)
            read
            bash $wp/uninstall.sh
            clear && echo "koolproxy已卸载！"
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

if [ ! -z "$1" ];then
    control_koolproxy
    exit 0
fi

clear && pannel

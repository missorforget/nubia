#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

RED="\033[31m"      # Error message
GREEN="\033[32m"    # Success message
YELLOW="\033[33m"   # Warning message
BLUE="\033[36m"     # Info message

colorEcho(){
    COLOR=$1
    echo -e "${COLOR}${@:2}\033[0m"
    echo
}

cmd_need(){
    colorEcho $BLUE "正在安装 $1 ..."
    [ -z "$(command -v yum)" ] && CHECK="dpkg -l" || CHECK="rpm -qa"
    [ -z "$(command -v yum)" ] && Installer="apt-get" || Installer="yum"
    var="0"
    for command in $1;do
        $CHECK | grep "$command"
        if [ "$?" != "0" ];then
            [ "$var" = "0" ] && apt-get update && var="1"
            $Installer install $command -y
        fi
    done > /dev/null 2>&1
    [ "$?" != "0" ] && colorEcho $RED "相关命令安装失败！" && exit 1
}

install_v2ray(){
    colorEcho $BLUE "正在安装V2Ray核心..."
    rm -rf /tmp/v2ray && mkdir -p /tmp/v2ray && cd /tmp/v2ray
    v2ray_latest_version=$(curl -s https://github.com/v2ray/v2ray-core/releases/latest | sed 's|.*tag/\(.*\)".*|\1|')
    wget -q -N --no-check-certificate https://github.com/v2ray/v2ray-core/releases/download/${v2ray_latest_version}/v2ray-linux-64.zip
    unzip -q -o v2ray-linux-64.zip
    $(command -v cp) -f $(find . -size +8000k -name v2ray) $wp ; $(command -v cp) -f $(find . -size +8000k -name v2ctl) $wp
    chmod -R 777 $wp

    colorEcho $BLUE "正在开启V2Ray自启程序..."
    cat $wp/v2ray.service > /etc/systemd/system/v2ray.service
    cat $wp/koolproxy.service > /etc/systemd/system/koolproxy.service
    systemctl daemon-reload

    colorEcho $BLUE "正在安装V2Ray控制面板..."
    cat $wp/manage_pannel.sh > /bin/v2
    chmod +x /bin/v2
    
    colorEcho $BLUE "正在开启自动更新程序..."
    sed -i '/v2ray_update\.sh/d' /etc/crontab
    echo "00 03 * * * root $wp/v2ray_update.sh" >> /etc/crontab
}

config_reload() {
    echo -e '{\n  "inbound": {\n    "port": '$(sed -n "1p" $wp/v2ray.ini | awk '{print $1}')',\n    "protocol": "vmess",\n    "settings": {\n      "clients": [\n        {\n          "id": "'$(sed -n "1p" $wp/v2ray.ini | awk '{print $2}')'",\n          "alterId": 100\n        }\n      ]\n    },\n    "streamSettings": {\n      "network": "tcp",\n      "tcpSettings": {\n        "header": {\n          "type": "http",\n          "response": {\n            "version": "1.1",\n            "status": "200",\n            "reason": "OK",\n            "headers": {\n              "Content-Type": [\n                "application/octet-stream",\n                "application/x-msdownload",\n                "text/html",\n                "application/x-shockwave-flash"\n              ],\n              "Connection": [\n                "keep-alive"\n              ]\n            }\n          }\n        }\n      }\n    }\n  },\n  "outbound": {\n    "protocol": "freedom",\n    "settings": {}\n  }\n}' > $wp/config.json
}

add_one_port(){
    read -p $'\033[33m请添加一个端口[默认随机]: \033[0m' Port
    [ -z "$Port" ] && Port=$(($RANDOM+37))
    echo
    read -p $'\033[33m请设置UUID[默认随机]: \033[0m' UUID
    [ -z "$UUID" ] && UUID=$(cat /proc/sys/kernel/random/uuid)
    echo
    echo "$Port $UUID" > $wp/v2ray.ini
    config_reload
}

main(){
    cmd_need "unzip wget curl net-tools"
    install_v2ray
    add_one_port
    systemctl enable v2ray.service >/dev/null 2>&1; systemctl start v2ray.service
    colorEcho $GREEN "V2Ray安装完成！输入v2可进入控制面板！"
}

main

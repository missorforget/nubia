#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

v2ray=on
koolproxy=off

old_core=$($wp/v2ray -version | sed -n "1p" | awk '{print $2}' | sed "s|v||")
latest_core=$(curl -s https://github.com/v2ray/v2ray-core/releases/latest | sed 's|.*tag/v\(.*\)".*|\1|')

update_v2ray() {
    rm -rf /tmp/v2ray && mkdir -p /tmp/v2ray && cd /tmp/v2ray
    wget -q -N --no-check-certificate https://github.com/v2ray/v2ray-core/releases/download/v${latest_core}/v2ray-linux-64.zip
    unzip -q -o v2ray-linux-64.zip
    $(command -v cp) -f $(find . -size +8000k -name v2ray) $wp ; $(command -v cp) -f $(find . -size +8000k -name v2ctl) $wp
    chmod -R 777 $wp
    [ ! -z $(pgrep v2ray) ] && systemctl restart v2ray.service
}

update_koolproxy() {
    rm -rf /tmp/koolproxy && mkdir -p /tmp/koolproxy && cd /tmp/koolproxy
    wget -q -N --no-check-certificate https://kprule.com/koolproxy.txt
    koolproxy_size=$(ls -hl koolproxy.txt | awk '{print $5}' | sed 's|K||')
    if (($koolproxy_size>400));then
        cat koolproxy.txt > $wp/koolproxy.txt
        [ ! -z $(pgrep koolproxy) ] && systemctl restart koolproxy.service
    fi
}

main() {
    [ "$v2ray" = "on" ] && [ "$old_core" != "$latest_core" ] && update_v2ray
    [ "$koolproxy" = "on" ] && update_koolproxy
}

main

#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

systemctl disable v2ray.service >/dev/null 2>&1
systemctl stop v2ray.service

rm -rf $wp
rm -f /etc/systemd/system/v2ray.service
rm -f /bin/v2

sed -i '/v2ray_update\.sh/d' /etc/crontab
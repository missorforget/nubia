#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp="/usr/local/v2ray"

systemctl disable v2ray.service >/dev/null 2>&1
systemctl kill v2ray.service
systemctl disable koolproxy.service >/dev/null 2>&1
systemctl kill koolproxy.service

iptables -t nat -D OUTPUT -p tcp -m ttl --ttl-eq 160 -j ACCEPT
iptables -t nat -D OUTPUT -p tcp --dport 80 -j REDIRECT --to 3000

rm -rf $wp
rm -f /etc/systemd/system/v2ray.service
rm -f /etc/systemd/system/koolproxy.service
rm -f /bin/v2

sed -i '/v2ray_update\.sh/d' /etc/crontab